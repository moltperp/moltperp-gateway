# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** Bready
- **What to call them:** Bready
- **Pronouns:** _(optional)_
- **Timezone:**
- **Notes:**

## Context

We will mainly be building crypto tools.

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
